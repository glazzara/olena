#!/bin/sh

######################
# WITHOUT MASK Q = 4 #
######################

../histo mp00411c.ppm 4 quant_q4.ppm histo_all_q4.dump proj1_all_q4.pgm

../opening 4 histo_all_q4.dump 1000 opened_all_q4.dump proj2_all_q4.pgm

../regmax mp00411c.ppm 4 quant_q4.ppm histo_all_q4.dump opened_all_q4.dump \
          labeled_all_q4.dump proj3_all_q4.ppm colormap_all_q4.txt \
          mean3_all_q4.ppm stats3_all_q4.txt

../iz labeled_all_q4.dump 0 mp00411c.ppm 4 quant_q4.ppm histo_all_q4.dump \
      colormap_all_q4.txt iz_all_q4.dump proj4_all_q4.ppm mean4_all_q4.ppm \
      stats4_all_q4.txt

########################
# WITH THIN MASK Q = 4 #
########################

 ../histo mp00411c.ppm 4 quant_q4.ppm histo_thin_q4.dump proj1_thin_q4.pgm \
          mp00411c_thin.pbm

../opening 4 histo_thin_q4.dump 1000 opened_thin_q4.dump proj2_thin_q4.pgm

../regmax mp00411c.ppm 4 quant_q4.ppm histo_thin_q4.dump opened_thin_q4.dump \
          labeled_thin_q4.dump proj3_thin_q4.ppm colormap_thin_q4.txt \
          mean3_thin_q4.ppm stats3_thin_q4.txt

../iz labeled_thin_q4.dump 0 mp00411c.ppm 4 quant_q4.ppm histo_thin_q4.dump \
      colormap_thin_q4.txt iz_thin_q4.dump proj4_thin_q4.ppm mean4_thin_q4.ppm \
      stats4_thin_q4.txt

#########################
# WITH THICK MASK Q = 4 #
#########################

../histo mp00411c.ppm 4 quant_q4.ppm histo_thick_q4.dump proj1_thick_q4.pgm \
         mp00411c_thick.pbm

../opening 4 histo_thick_q4.dump 1000 opened_thick_q4.dump proj2_thick_q4.pgm

../regmax mp00411c.ppm 4 quant_q4.ppm histo_thick_q4.dump opened_thick_q4.dump \
          labeled_thick_q4.dump proj3_thick_q4.ppm colormap_thick_q4.txt \
          mean3_thick_q4.ppm stats3_thick_q4.txt

../iz labeled_thick_q4.dump 0 mp00411c.ppm 4 quant_q4.ppm histo_thick_q4.dump \
      colormap_thick_q4.txt iz_thick_q4.dump proj4_thick_q4.ppm \
      mean4_thick_q4.ppm stats4_thick_q4.txt

######################
# WITHOUT MASK Q = 5 #
######################

../histo mp00411c.ppm 5 quant_q5.ppm histo_all_q5.dump proj1_all_q5.pgm

../opening 5 histo_all_q5.dump 1000 opened_all_q5.dump proj2_all_q5.pgm

../regmax mp00411c.ppm 5 quant_q5.ppm histo_all_q5.dump opened_all_q5.dump \
          labeled_all_q5.dump proj3_all_q5.ppm colormap_all_q5.txt \
          mean3_all_q5.ppm stats3_all_q5.txt

../iz labeled_all_q5.dump 0 mp00411c.ppm 5 quant_q5.ppm histo_all_q5.dump \
      colormap_all_q5.txt iz_all_q5.dump proj4_all_q5.ppm mean4_all_q5.ppm \
      stats4_all_q5.txt

########################
# WITH THIN MASK Q = 5 #
########################

 ../histo mp00411c.ppm 5 quant_q5.ppm histo_thin_q5.dump proj1_thin_q5.pgm \
          mp00411c_thin.pbm

../opening 5 histo_thin_q5.dump 1000 opened_thin_q5.dump proj2_thin_q5.pgm

../regmax mp00411c.ppm 5 quant_q5.ppm histo_thin_q5.dump opened_thin_q5.dump \
          labeled_thin_q5.dump proj3_thin_q5.ppm colormap_thin_q5.txt \
          mean3_thin_q5.ppm stats3_thin_q5.txt

../iz labeled_thin_q5.dump 0 mp00411c.ppm 5 quant_q5.ppm histo_thin_q5.dump \
      colormap_thin_q5.txt iz_thin_q5.dump proj4_thin_q5.ppm mean4_thin_q5.ppm \
      stats4_thin_q5.txt

#########################
# WITH THICK MASK Q = 5 #
#########################

../histo mp00411c.ppm 5 quant_q5.ppm histo_thick_q5.dump proj1_thick_q5.pgm \
         mp00411c_thick.pbm

../opening 5 histo_thick_q5.dump 1000 opened_thick_q5.dump proj2_thick_q5.pgm

../regmax mp00411c.ppm 5 quant_q5.ppm histo_thick_q5.dump opened_thick_q5.dump \
          labeled_thick_q5.dump proj3_thick_q5.ppm colormap_thick_q5.txt \
          mean3_thick_q5.ppm stats3_thick_q5.txt

../iz labeled_thick_q5.dump 0 mp00411c.ppm 5 quant_q5.ppm histo_thick_q5.dump \
      colormap_thick_q5.txt iz_thick_q5.dump proj4_thick_q5.ppm \
      mean4_thick_q5.ppm stats4_thick_q5.txt


